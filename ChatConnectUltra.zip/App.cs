namespace ChatConnectUltra;

public partial class App { }
